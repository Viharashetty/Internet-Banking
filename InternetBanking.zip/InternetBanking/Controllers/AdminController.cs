﻿using InternetBanking.Models;
using System.Linq;
using System.Web.Mvc;

namespace InternetBanking.Controllers
{
    public class AdminController : Controller
    {
        InternetBankingEntities13 db = new InternetBankingEntities13();
        public ActionResult AdminRegister()
        {
            AdminUser user = new AdminUser();
            return View(user);
        }
        //POST: Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AdminRegister(AdminUser user)
        {
            if (ModelState.IsValid)
            {
                var check = db.AdminLogins.FirstOrDefault(s => s.UserName == user.UserName);
                if (check == null)
                {
                    AdminLogin userTable = new AdminLogin();
                    userTable.UserName = user.UserName;
                    userTable.Password = user.Password;
                    db.AdminLogins.Add(userTable);
                    db.SaveChanges();
                    ViewBag.Message = "Account Created Successfully";
                    return RedirectToAction("AdminLogin");
                }
                else
                {
                    ViewBag.Message = "User Name already exist";
                    return View();
                }
            }
            return View();
        }
        public ActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AdminLogin(AdminLogin user)
        {
            if (ModelState.IsValid)
            {
                //var data = ID.Equals(netBank.UserID)).FirstOrDefault();
                var obj = db.AdminLogins.Where(a => a.UserName.Equals(user.UserName) && a.Password.Equals(user.Password)).FirstOrDefault();
                {
                    if (obj != null)
                    {
                        return RedirectToAction("../Account/userList");
                    }
                    else
                    {
                        ViewBag.error = "Login failed";
                        return RedirectToAction("AdminLogin");
                    }
                }
            }
            return View();
        }
        //Logout
        public ActionResult Logout()
        {
            Session.Clear();//remove session
            return RedirectToAction("Login");
        }
    }
}