﻿using InternetBanking.Models;
using System.Linq;
using System.Web.Mvc;

namespace InternetBanking.Controllers
{
    public class AccountController : Controller
    {
            // GET: Account
            InternetBankingEntities13 db = new InternetBankingEntities13();        
            //GET: Register
            public ActionResult Register()
            {
                User user = new User();
                return View(user);
            }
            //POST: Register
            [HttpPost]
            [ValidateAntiForgeryToken]
            public ActionResult Register(User user)
            {
                if (ModelState.IsValid)
                {
                var check = db.AuthenticationTables.FirstOrDefault(s => s.MobileNumber == user.MobileNumber);
                if (check == null)
                {
                        AuthenticationTable userTable = new AuthenticationTable();
                        tb_Admin1 adminTable = new tb_Admin1();
                        adminTable.Account_Number = user.Account_Number;                     
                        adminTable.Account_Holder_Name = user.Account_Holder_Name;
                        adminTable.City = user.City;
                        adminTable.Account_Number = user.Account_Number;
                        adminTable.Country = user.Country;
                        userTable.Password = user.Password;
                        adminTable.Amount = user.Amount;
                        userTable.MobileNumber = user.MobileNumber;
                        db.AuthenticationTables.Add(userTable);
                        db.tb_Admin1.Add(adminTable);
                        db.SaveChanges();
                        ViewBag.Message = "Account Created Successfully";
                        return RedirectToAction("Login");
                    }
                    else
                    {
                        ViewBag.Message = "Mobile number already exist";
                        return View();
                    }
                }
                return View();
            }
            public ActionResult Login()
            {
                return View();
            }
            [HttpPost]
            [ValidateAntiForgeryToken]
            public ActionResult Login(AuthenticationTable netBank)
            {
                if (ModelState.IsValid)
                {
                    var obj = db.AuthenticationTables.Where(a => a.MobileNumber.Equals(netBank.MobileNumber) && a.Password.Equals(netBank.Password)).FirstOrDefault();
                    {
                        if (obj != null)
                        {
                            var data = db.tb_Admin1.Where(a => a.Account_Number.Equals(obj.Account_Number)).FirstOrDefault();
                            Session["Account_Holder_Name"] = data.Account_Holder_Name;
                            Session["MobileNumber"] = obj.MobileNumber;
                            Session["City"] = data.City;
                            Session["Country"] = data.Country;
                            Session["Account_Number"] = obj.Account_Number;
                            Session["Amount"] = data.Amount;
                            return RedirectToAction("Index");
                        }
                        else
                        {
                            ViewBag.error = "Login failed";
                            return RedirectToAction("Login");
                        }
                    }
                }
                return View();
            }
            //Logout
            public ActionResult Logout()
            {
                Session.Clear();
                return RedirectToAction("Login");
            }
        // GET: Home
        public ActionResult Index()
        {
            if (Session["Account_Number"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
        public ActionResult ChangePassword()
            {
                return View();
            }
            [HttpPost]
            public ActionResult ChangePassword(AuthenticationTable obj, string btn)
            {
                if (btn == "ChangePassword")
                {
                    var data = db.AuthenticationTables.Where(obj1 => obj1.Account_Number == obj.Account_Number).FirstOrDefault();

                    if (obj.Password != data.Password)
                    {
                        data.Password = obj.Password;
                        int saved = db.SaveChanges();
                        if (saved == 1)
                        {
                            ViewBag.data = "Password changed Successfully";
                        }
                        else
                        {
                            ViewBag.data = "password change unsuccessfull";
                        }
                    }
                    else
                    {
                        ViewBag.data = "Password cannot be same as previous one";
                    }
                }
                return View();
            }
            // GET: Account
            public ActionResult AccountDetails()
            {
                return View();
            }
            [HttpPost]
            public ActionResult AccountDetails(tb_Admin1 obj, string btn)
            {
                if (btn == "Withdraw")
                {
                    var data = db.tb_Admin1.Where(obj1 => obj1.Account_Number == obj.Account_Number).FirstOrDefault();

                    if (obj.Amount <= data.Amount)
                    {
                        data.Amount -= obj.Amount;
                        int mess = db.SaveChanges();
                        if (mess == 1)
                        {
                            ViewBag.data = "Withdraw Success";
                        }
                        else
                        {
                            ViewBag.data = "Withdraw not Success";
                        }
                    }
                    else
                    {
                        ViewBag.data = "Insufficient balance";
                    }
                }
                else if (btn == "Deposit")
                {
                    var data = db.tb_Admin1.Where(obj2 => obj2.Account_Number == obj.Account_Number).FirstOrDefault();
                    data.Amount += obj.Amount;
                    int mess = db.SaveChanges();
                    if (mess == 1)
                    {
                        ViewBag.data = "Deposit Success";
                    }
                    else
                    {
                        ViewBag.data = "Deposit not Success";
                    }
                }
                else if (btn == "Balance")
                {
                    var data = db.tb_Admin1.Where(obj3 => obj3.Account_Number == obj.Account_Number).FirstOrDefault();
                    ViewBag.show = data.Amount;
                }
                else if(btn=="Interest")
                {
                    var data = db.tb_Admin1.Where(obj3 => obj3.Account_Number == obj.Account_Number).FirstOrDefault();
                    ViewBag.show = data.Amount + ((data.Amount * 1 * 5) / 100); 
                }
            return View();
            }
            public ActionResult userList()
            {
                return View(db.AuthenticationTables.ToList());
            }
            public ActionResult Details(int id)
            {
                return View(db.tb_Admin1.Where(a => a.Account_Number == id).FirstOrDefault());
            }
            public ActionResult Transfer()
            {
                return View();
            }
            [HttpPost]
            [ValidateAntiForgeryToken]
            public ActionResult Transfer(tb_Admin1 obj, tb_Admin1 ob1, string btn)
            {
                if (btn == "Transfer")
                {
                    var dataReceiver = db.tb_Admin1.Where(x => x.Account_Holder_Name == ob1.Account_Holder_Name).FirstOrDefault();
                    var dataSender = db.tb_Admin1.Where(obj1 => obj1.Account_Number == obj.Account_Number).FirstOrDefault();

                    if (dataSender.Amount >= obj.Amount)
                    {
                        dataSender.Amount -= obj.Amount;
                        dataReceiver.Amount += obj.Amount;
                        int saved = db.SaveChanges();
                        if (saved == 2)
                        {
                            ViewBag.data = "Transaction Successful";
                        }
                        else
                        {
                            ViewBag.data = "Transaction Failed";
                        }
                    }
                    else
                    {
                        ViewBag.data = "Insufficient Balance,Cannot Transfer Amount";
                    }
                }
                return View();
            } 
    }
}